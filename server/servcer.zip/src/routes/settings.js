const express = require('express');
const {
  getSettings,
  updatePersonalInfo,
  updateAddress,
  updatePreferences,
  updateNotificationSettings,
  updatePrivacySettings,
  changePassword,
  changeEmail,
  uploadAvatar,
  deleteAvatar,
  deactivateAccount,
  deleteAccount
} = require('../controllers/settingsController');
const { protect } = require('../middleware/auth');
const { uploadAvatar: uploadAvatarMiddleware } = require('../middleware/upload');

const router = express.Router();

// Protect all routes
router.use(protect);

// Settings routes
router.get('/', getSettings);

// Personal information
router.put('/personal-info', updatePersonalInfo);

// Address
router.put('/address', updateAddress);

// Preferences
router.put('/preferences', updatePreferences);

// Notifications
router.put('/notifications', updateNotificationSettings);

// Privacy
router.put('/privacy', updatePrivacySettings);

// Security
router.put('/password', changePassword);
router.put('/email', changeEmail);

// Avatar - Use uploadAvatarMiddleware for proper file handling
router.post('/avatar', uploadAvatarMiddleware.single('avatar'), uploadAvatar);
router.delete('/avatar', deleteAvatar);

// Account management
router.put('/deactivate', deactivateAccount);
router.delete('/account', deleteAccount);

module.exports = router;
