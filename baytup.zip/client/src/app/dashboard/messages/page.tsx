'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import moment from 'moment';
import io, { Socket } from 'socket.io-client';
import { useApp } from '@/contexts/AppContext';
import { useTranslation } from '@/hooks/useTranslation';
import AdminMessagesView from '@/components/messages/AdminMessagesView';

interface Participant {
  user: {
    _id: string;
    firstName: string;
    lastName: string;
    avatar: string;
  };
  lastReadAt: string;
}

interface Message {
  _id: string;
  sender: {
    _id: string;
    firstName: string;
    lastName: string;
    avatar: string;
  };
  content: string;
  type: string;
  attachments?: { url: string; type: string }[];
  readBy: string[];
  isEdited: boolean;
  editedAt?: string;
  originalContent?: string;
  createdAt: string;
  updatedAt: string;
}

interface Conversation {
  _id: string;
  participants: Participant[];
  listing?: {
    _id: string;
    title: string;
    images: { url: string; isPrimary: boolean }[];
    address: {
      city: string;
      country: string;
    };
  };
  booking?: {
    _id: string;
    startDate: string;
    endDate: string;
    status: string;
  };
  lastMessage?: {
    content: string;
    sender?: string | {
      _id: string;
      firstName: string;
      lastName: string;
      avatar: string;
    };
    sentAt?: string;
    createdAt?: string;
    type?: string;
  };
  status: string;
  unreadCount: number;
  createdAt: string;
  updatedAt: string;
}

interface MessageStats {
  summary: {
    totalConversations: number;
    archivedConversations: number;
    totalUnread: number;
    activeConversations: number;
  };
  recentActivity: any[];
}

export default function MessagesPage() {
  const { state } = useApp();
  const user = state.user;
  const t = useTranslation('messages');

  // If user is admin, render admin view
  if (user?.role === 'admin') {
    return <AdminMessagesView />;
  }

  // Otherwise, render regular user view
  const router = useRouter();
  const searchParams = useSearchParams();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [stats, setStats] = useState<MessageStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'active' | 'archived'>('active');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [messageToDelete, setMessageToDelete] = useState<Message | null>(null);
  const [showArchiveModal, setShowArchiveModal] = useState(false);
  const [conversationToArchive, setConversationToArchive] = useState<Conversation | null>(null);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [editContent, setEditContent] = useState('');
  const [showNewConversationModal, setShowNewConversationModal] = useState(false);
  const [conversationInitialized, setConversationInitialized] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const isInitializedRef = useRef(false);

  // Initialize socket connection once on mount
  useEffect(() => {
    // Prevent double initialization in React Strict Mode
    if (isInitializedRef.current) {
      return;
    }

    // Get current user ID from token
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setCurrentUserId(payload.id);
      } catch (error) {
        console.error('Error parsing token:', error);
      }
    }

    // Initialize socket only if not already connected
    if (!socketRef.current || !socketRef.current.connected) {
      initializeSocket();
      isInitializedRef.current = true;
    }

    // Cleanup only on true unmount (not on Strict Mode re-render)
    return () => {
      // In Strict Mode, this runs twice. We only want to cleanup on true unmount.
      // We can detect true unmount by checking if the component is really being removed
    };
  }, []); // Empty deps - run only on mount/unmount

  // Separate cleanup effect that runs on true unmount
  useEffect(() => {
    return () => {
      // This cleanup runs when the component is truly unmounting
      // Not during React Strict Mode's double-invocation
      const isUnmounting = !document.querySelector('[data-messages-page]');
      if (isUnmounting && socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
        isInitializedRef.current = false;
      }
    };
  }, [])

  // Fetch data when filter changes
  useEffect(() => {
    fetchData();
  }, [filterStatus]);

  // Handle ?user= query parameter for creating/opening conversation
  useEffect(() => {
    const recipientId = searchParams?.get('user');

    if (recipientId && !conversationInitialized && currentUserId && conversations.length >= 0) {

      // Check if conversation already exists with this user
      const existingConversation = conversations.find(conv => {
        const otherUser = conv.participants.find(
          p => p.user._id !== currentUserId
        );
        return otherUser?.user._id === recipientId;
      });

      if (existingConversation) {
        fetchMessages(existingConversation._id);
        setConversationInitialized(true);
      } else {
        createOrGetConversationWithUser(recipientId)
          .then(() => {
            setConversationInitialized(true);
          })
          .catch(err => {
            console.error('Failed to create conversation:', err);
          });
      }
    }
  }, [searchParams, conversations, currentUserId, conversationInitialized]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const initializeSocket = () => {
    // Prevent duplicate socket creation
    if (socketRef.current && socketRef.current.connected) {
      return;
    }

    // Disconnect existing socket if present but not connected
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      console.warn('⚠️ No authentication token found, skipping Socket.IO connection');
      return;
    }

    // Use SOCKET_URL (without /api) for Socket.IO connection
    const socketUrl = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000';

    socketRef.current = io(socketUrl, {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5
    });

    socketRef.current.on('connect', () => {
    });

    socketRef.current.on('disconnect', () => {
    });

    socketRef.current.on('error', (error: any) => {
      console.error('Socket error:', error);
      toast.error(error.message || ((t as any)?.toast?.connectionError || 'Connection error'));
    });

    // New message received
    socketRef.current.on('new_message', (data: { conversationId: string; message: Message }) => {

      // Only add message if it's for the currently selected conversation
      if (selectedConversation && data.conversationId === selectedConversation._id) {
        setMessages(prev => [...prev, data.message]);
      }

      // Update conversation list
      fetchConversations();
    });

    // Message notification (for other conversations)
    socketRef.current.on('message_notification', (data: { conversationId: string; message: Message }) => {
      fetchConversations();

      // Show notification if not viewing this conversation
      if (!selectedConversation || data.conversationId !== selectedConversation._id) {
        const name = `${data.message.sender.firstName} ${data.message.sender.lastName}`;
        const message = (t as any)?.toast?.newMessage ? (t as any).toast.newMessage.replace('{name}', name) : `New message from ${name}`;
        toast.success(message);
      }
    });

    // Message updated
    socketRef.current.on('message_updated', (data: { conversationId: string; message: Message }) => {
      if (selectedConversation && data.conversationId === selectedConversation._id) {
        setMessages(prev =>
          prev.map(msg => (msg._id === data.message._id ? data.message : msg))
        );
      }
    });

    // Message deleted
    socketRef.current.on('message_deleted', (data: { conversationId: string; messageId: string }) => {
      if (selectedConversation && data.conversationId === selectedConversation._id) {
        setMessages(prev => prev.filter(msg => msg._id !== data.messageId));
      }
      fetchConversations();
    });

    // Typing indicators
    socketRef.current.on('user_typing', (data: { userId: string; userName: string; conversationId: string }) => {
    });

    socketRef.current.on('user_stop_typing', (data: { userId: string; conversationId: string }) => {
    });

    // Messages read notification
    socketRef.current.on('messages_read', (data: { conversationId: string; userId: string; readAt: string }) => {
    });

    // Conversation joined confirmation
    socketRef.current.on('conversation_joined', (data: { conversationId: string }) => {
    });
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      await Promise.all([fetchConversations(), fetchStats()]);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Create or get conversation with a specific user
  const createOrGetConversationWithUser = async (recipientId: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/conversations`,
        { recipientId },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      const conversation = response.data.data.conversation;

      // Refresh conversations list
      await fetchConversations();

      // Select and load the conversation
      await fetchMessages(conversation._id);

      return conversation;
    } catch (error: any) {
      console.error('Error creating/getting conversation:', error);
      toast.error(error.response?.data?.message || ((t as any)?.toast?.sendFailed || 'Failed to start conversation'));
      throw error;
    }
  };

  const fetchConversations = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/conversations`,
        {
          headers: { Authorization: `Bearer ${token}` },
          params: { status: filterStatus }
        }
      );
      setConversations(response.data.data.conversations);
    } catch (error: any) {
      console.error('Error fetching conversations:', error);
      if (error.response?.status === 401) {
        toast.error((t as any)?.toast?.loginRequired || 'Please login to view messages');
        router.push('/login');
      }
    }
  };

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/stats`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setStats(response.data.data);
    } catch (error: any) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchMessages = async (conversationId: string) => {
    try {
      setMessagesLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/conversations/${conversationId}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setMessages(response.data.data.messages);
      setSelectedConversation(response.data.data.conversation);

      // Join conversation room via Socket.IO
      if (socketRef.current?.connected) {
        socketRef.current.emit('join_conversation', conversationId);
      }

      // Mark conversation as read
      await markConversationAsRead(conversationId);

      // Also emit socket event for real-time read status
      if (socketRef.current?.connected) {
        socketRef.current.emit('mark_as_read', conversationId);
      }

      fetchConversations(); // Update conversation list with unread counts
    } catch (error: any) {
      console.error('Error fetching messages:', error);
      toast.error((t as any)?.toast?.loadFailed || 'Failed to load messages');
    } finally {
      setMessagesLoading(false);
    }
  };

  const markConversationAsRead = async (conversationId: string) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/conversations/${conversationId}/read`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
    } catch (error: any) {
      console.error('Error marking conversation as read:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return;

    const messageContent = newMessage.trim();
    setNewMessage(''); // Clear input immediately for better UX

    try {
      // Use Socket.IO for real-time messaging if connected
      if (socketRef.current?.connected) {
        socketRef.current.emit('send_message', {
          conversationId: selectedConversation._id,
          content: messageContent,
          type: 'text'
        });
      } else {
        // Fallback to REST API if socket is not connected
        const token = localStorage.getItem('token');
        const response = await axios.post(
          `${process.env.NEXT_PUBLIC_API_URL}/messages`,
          {
            conversationId: selectedConversation._id,
            content: messageContent
          },
          {
            headers: { Authorization: `Bearer ${token}` }
          }
        );

        // Message will be added via socket event
        setMessages([...messages, response.data.data.message]);
        fetchConversations();
      }
    } catch (error: any) {
      console.error('Error sending message:', error);
      toast.error(error.response?.data?.message || ((t as any)?.toast?.sendFailed || 'Failed to send message'));
      setNewMessage(messageContent); // Restore message on error
    }
  };

  const handleEditMessage = async () => {
    if (!editingMessage || !editContent.trim()) return;

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/${editingMessage._id}`,
        { content: editContent.trim() },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      toast.success((t as any)?.toast?.updateSuccess || 'Message updated successfully');
      setEditingMessage(null);
      setEditContent('');
      if (selectedConversation) {
        fetchMessages(selectedConversation._id);
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || ((t as any)?.toast?.updateFailed || 'Failed to update message'));
    }
  };

  const handleDeleteMessage = async () => {
    if (!messageToDelete) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/${messageToDelete._id}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      toast.success((t as any)?.toast?.deleteSuccess || 'Message deleted successfully');
      setShowDeleteModal(false);
      setMessageToDelete(null);
      setMessages(messages.filter(msg => msg._id !== messageToDelete._id));
      fetchConversations();
    } catch (error: any) {
      toast.error(error.response?.data?.message || ((t as any)?.toast?.deleteFailed || 'Failed to delete message'));
    }
  };

  const handleArchiveConversation = async () => {
    if (!conversationToArchive) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint =
        conversationToArchive.status === 'active'
          ? `/messages/conversations/${conversationToArchive._id}/archive`
          : `/messages/conversations/${conversationToArchive._id}/unarchive`;

      await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}${endpoint}`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      toast.success(
        conversationToArchive.status === 'active'
          ? ((t as any)?.toast?.archiveSuccess || 'Conversation archived')
          : ((t as any)?.toast?.unarchiveSuccess || 'Conversation unarchived')
      );
      setShowArchiveModal(false);
      setConversationToArchive(null);
      setSelectedConversation(null);
      setMessages([]);
      fetchData();
    } catch (error: any) {
      toast.error(
        error.response?.data?.message ||
          (conversationToArchive.status === 'active'
            ? ((t as any)?.toast?.archiveFailed || 'Failed to archive conversation')
            : ((t as any)?.toast?.unarchiveFailed || 'Failed to unarchive conversation'))
      );
    }
  };

  const handleDeleteConversation = async () => {
    if (!selectedConversation) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${process.env.NEXT_PUBLIC_API_URL}/messages/conversations/${selectedConversation._id}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      toast.success((t as any)?.toast?.conversationDeleteSuccess || 'Conversation deleted successfully');
      setSelectedConversation(null);
      setMessages([]);
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || ((t as any)?.toast?.conversationDeleteFailed || 'Failed to delete conversation'));
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatMessageTime = (date: string) => {
    const messageDate = moment(date);
    const now = moment();

    if (messageDate.isSame(now, 'day')) {
      return messageDate.format('HH:mm');
    } else if (messageDate.isSame(now.clone().subtract(1, 'day'), 'day')) {
      return (t as any)?.time?.yesterday || 'Yesterday';
    } else if (messageDate.isAfter(now.clone().subtract(7, 'days'))) {
      return messageDate.format('ddd');
    } else {
      return messageDate.format('MMM DD');
    }
  };

  const formatFullTime = (date: string) => {
    return moment(date).format('MMM DD, YYYY [at] HH:mm');
  };

  const getImageUrl = (url: string) => {
    if (!url) return '/uploads/users/default-avatar.png';
    if (url.startsWith('http')) return url;

    // Remove /api prefix if present
    const cleanPath = url.startsWith('/api') ? url.substring(4) : url;
    const baseUrl = process.env.NEXT_PUBLIC_API_URL?.replace('/api', '') || 'http://localhost:5000';
    return `${baseUrl}${cleanPath}`;
  };

  const getOtherParticipant = (conversation: Conversation) => {
    return conversation.participants.find(
      p => p.user._id !== currentUserId
    )?.user;
  };

  const canEditMessage = (message: Message) => {
    if (message.sender._id !== currentUserId) return false;
    const messageTime = moment(message.createdAt);
    const now = moment();
    return now.diff(messageTime, 'minutes') <= 15;
  };

  const filteredConversations = conversations.filter(conv => {
    if (!searchQuery) return true;
    const otherUser = getOtherParticipant(conv);
    const searchLower = searchQuery.toLowerCase();
    return (
      otherUser?.firstName.toLowerCase().includes(searchLower) ||
      otherUser?.lastName.toLowerCase().includes(searchLower) ||
      conv.lastMessage?.content.toLowerCase().includes(searchLower) ||
      conv.listing?.title.toLowerCase().includes(searchLower)
    );
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF6B35] mx-auto"></div>
          <p className="mt-4 text-gray-600">{(t as any)?.messagesArea?.loading || 'Loading messages...'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8" data-messages-page>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{(t as any)?.header?.title || 'Messages'}</h1>
          <p className="mt-2 text-gray-600">
            {(t as any)?.header?.subtitle || 'Communicate with hosts and manage your conversations'}
          </p>
        </div>

        {/* Statistics Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-[#FF6B35]">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{(t as any)?.stats?.totalConversations || 'Total Conversations'}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">
                    {stats.summary.totalConversations}
                  </p>
                </div>
                <div className="p-3 bg-orange-50 rounded-lg">
                  <svg className="w-6 h-6 text-[#FF6B35]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{(t as any)?.stats?.unreadMessages || 'Unread Messages'}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">
                    {stats.summary.totalUnread}
                  </p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{(t as any)?.stats?.archived || 'Archived'}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">
                    {stats.summary.archivedConversations}
                  </p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <svg className="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Messages Layout */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden" style={{ height: '600px' }}>
          <div className="flex h-full">
            {/* Conversations List */}
            <div className="w-full md:w-1/3 border-r border-gray-200 flex flex-col">
              {/* Conversations Header */}
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">{(t as any)?.conversations?.title || 'Conversations'}</h2>
                  <button
                    onClick={() => setShowNewConversationModal(true)}
                    className="p-2 text-[#FF6B35] hover:bg-orange-50 rounded-lg transition-colors"
                    title={(t as any)?.conversations?.newConversation || 'New conversation'}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </button>
                </div>

                {/* Search */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder={(t as any)?.conversations?.searchPlaceholder || 'Search conversations...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6B35] focus:border-transparent"
                  />
                  <svg
                    className="absolute left-3 top-2.5 w-5 h-5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>

                {/* Filter Tabs */}
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => setFilterStatus('active')}
                    className={`flex-1 py-2 px-4 rounded-lg font-medium text-sm transition-colors ${
                      filterStatus === 'active'
                        ? 'bg-[#FF6B35] text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {(t as any)?.conversations?.filters?.active || 'Active'}
                  </button>
                  <button
                    onClick={() => setFilterStatus('archived')}
                    className={`flex-1 py-2 px-4 rounded-lg font-medium text-sm transition-colors ${
                      filterStatus === 'archived'
                        ? 'bg-[#FF6B35] text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {(t as any)?.conversations?.filters?.archived || 'Archived'}
                  </button>
                </div>
              </div>

              {/* Conversations List */}
              <div className="flex-1 overflow-y-auto">
                {filteredConversations.length === 0 ? (
                  <div className="p-8 text-center">
                    <svg
                      className="mx-auto h-12 w-12 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                      />
                    </svg>
                    <h3 className="mt-4 text-sm font-medium text-gray-900">{(t as any)?.conversations?.empty?.noConversations || 'No conversations'}</h3>
                    <p className="mt-2 text-sm text-gray-500">
                      {searchQuery
                        ? ((t as any)?.conversations?.empty?.noMatches || 'No conversations match your search')
                        : ((t as any)?.conversations?.empty?.startConversation || 'Start a conversation with a host')}
                    </p>
                  </div>
                ) : (
                  filteredConversations.map((conversation) => {
                    const otherUser = getOtherParticipant(conversation);
                    if (!otherUser) return null;

                    return (
                      <div
                        key={conversation._id}
                        onClick={() => fetchMessages(conversation._id)}
                        className={`p-4 border-b border-gray-200 cursor-pointer transition-colors ${
                          selectedConversation?._id === conversation._id
                            ? 'bg-orange-50'
                            : 'hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          {/* Avatar */}
                          <div className="relative w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                            <img
                              src={getImageUrl(otherUser.avatar)}
                              alt={`${otherUser.firstName} ${otherUser.lastName}`}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = '/uploads/users/default-avatar.png';
                              }}
                            />
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <h3 className="text-sm font-semibold text-gray-900 truncate">
                                {otherUser.firstName} {otherUser.lastName}
                              </h3>
                              {conversation.lastMessage && (
                                <span className="text-xs text-gray-500 ml-2">
                                  {formatMessageTime(conversation.lastMessage.sentAt || conversation.lastMessage.createdAt || conversation.updatedAt)}
                                </span>
                              )}
                            </div>

                            {conversation.listing && (
                              <p className="text-xs text-gray-500 truncate mb-1">
                                {conversation.listing.title}
                              </p>
                            )}

                            {conversation.lastMessage && (
                              <p className="text-sm text-gray-600 truncate">
                                {conversation.lastMessage.sender && typeof conversation.lastMessage.sender === 'object' && conversation.lastMessage.sender._id === currentUserId ? ((t as any)?.conversations?.youPrefix || 'You: ') : ''}
                                {conversation.lastMessage.content}
                              </p>
                            )}

                            {conversation.unreadCount > 0 && (
                              <span className="inline-block mt-1 px-2 py-0.5 bg-[#FF6B35] text-white text-xs font-medium rounded-full">
                                {conversation.unreadCount} {(t as any)?.conversations?.unreadBadge || 'new'}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 flex flex-col">
              {selectedConversation && !messagesLoading ? (
                <>
                  {/* Messages Header */}
                  <div className="p-4 border-b border-gray-200 bg-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="relative w-10 h-10 rounded-full overflow-hidden">
                          <img
                            src={getImageUrl(
                              getOtherParticipant(selectedConversation)?.avatar || ''
                            )}
                            alt="User avatar"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = '/uploads/users/default-avatar.png';
                            }}
                          />
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold text-gray-900">
                            {getOtherParticipant(selectedConversation)?.firstName}{' '}
                            {getOtherParticipant(selectedConversation)?.lastName}
                          </h3>
                          {selectedConversation.listing && (
                            <p className="text-xs text-gray-500">
                              {selectedConversation.listing.title}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setConversationToArchive(selectedConversation);
                            setShowArchiveModal(true);
                          }}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title={
                            selectedConversation.status === 'active'
                              ? ((t as any)?.messagesArea?.tooltips?.archive || 'Archive conversation')
                              : ((t as any)?.messagesArea?.tooltips?.unarchive || 'Unarchive conversation')
                          }
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                          </svg>
                        </button>
                        <button
                          onClick={handleDeleteConversation}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title={(t as any)?.messagesArea?.tooltips?.delete || 'Delete conversation'}
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Messages List */}
                  <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                    {messages.length === 0 ? (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-gray-500">{(t as any)?.messagesArea?.empty || 'No messages yet. Start the conversation!'}</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {messages.map((message, index) => {
                          const isOwnMessage = message.sender._id === currentUserId;
                          const showAvatar =
                            index === 0 ||
                            messages[index - 1].sender._id !== message.sender._id;

                          return (
                            <div
                              key={message._id}
                              className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                            >
                              <div
                                className={`flex items-end space-x-2 max-w-[70%] ${
                                  isOwnMessage ? 'flex-row-reverse space-x-reverse' : ''
                                }`}
                              >
                                {/* Avatar */}
                                {showAvatar ? (
                                  <div className="relative w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                                    <img
                                      src={getImageUrl(message.sender.avatar)}
                                      alt={message.sender.firstName}
                                      className="w-full h-full object-cover"
                                      onError={(e) => {
                                        const target = e.target as HTMLImageElement;
                                        target.src = '/uploads/users/default-avatar.png';
                                      }}
                                    />
                                  </div>
                                ) : (
                                  <div className="w-8 h-8 flex-shrink-0" />
                                )}

                                {/* Message Bubble */}
                                <div>
                                  <div
                                    className={`px-4 py-2 rounded-2xl ${
                                      isOwnMessage
                                        ? 'bg-[#FF6B35] text-white'
                                        : 'bg-white text-gray-900 border border-gray-200'
                                    }`}
                                  >
                                    {editingMessage?._id === message._id ? (
                                      <div className="space-y-2">
                                        <textarea
                                          value={editContent}
                                          onChange={(e) => setEditContent(e.target.value)}
                                          className="w-full px-2 py-1 text-gray-900 bg-white border border-gray-300 rounded resize-none focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
                                          rows={2}
                                        />
                                        <div className="flex gap-2">
                                          <button
                                            onClick={handleEditMessage}
                                            className="px-3 py-1 text-xs bg-white text-[#FF6B35] rounded hover:bg-gray-100"
                                          >
                                            {(t as any)?.messagesArea?.actions?.save || 'Save'}
                                          </button>
                                          <button
                                            onClick={() => {
                                              setEditingMessage(null);
                                              setEditContent('');
                                            }}
                                            className="px-3 py-1 text-xs bg-white text-gray-600 rounded hover:bg-gray-100"
                                          >
                                            {(t as any)?.messagesArea?.actions?.cancel || 'Cancel'}
                                          </button>
                                        </div>
                                      </div>
                                    ) : (
                                      <>
                                        <p className="text-sm break-words">{message.content}</p>
                                        {message.isEdited && (
                                          <span className="text-xs opacity-70 mt-1 block">
                                            {(t as any)?.messagesArea?.edited || '(edited)'}
                                          </span>
                                        )}
                                      </>
                                    )}
                                  </div>

                                  {/* Message Info */}
                                  <div
                                    className={`flex items-center gap-2 mt-1 ${
                                      isOwnMessage ? 'justify-end' : ''
                                    }`}
                                  >
                                    <span className="text-xs text-gray-500">
                                      {formatFullTime(message.createdAt)}
                                    </span>

                                    {isOwnMessage && !editingMessage && (
                                      <div className="flex gap-1">
                                        {canEditMessage(message) && (
                                          <button
                                            onClick={() => {
                                              setEditingMessage(message);
                                              setEditContent(message.content);
                                            }}
                                            className="text-xs text-gray-500 hover:text-[#FF6B35]"
                                          >
                                            {(t as any)?.messagesArea?.actions?.edit || 'Edit'}
                                          </button>
                                        )}
                                        <button
                                          onClick={() => {
                                            setMessageToDelete(message);
                                            setShowDeleteModal(true);
                                          }}
                                          className="text-xs text-gray-500 hover:text-red-600"
                                        >
                                          {(t as any)?.messagesArea?.actions?.delete || 'Delete'}
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                        <div ref={messagesEndRef} />
                      </div>
                    )}
                  </div>

                  {/* Message Input */}
                  <div className="p-4 border-t border-gray-200 bg-white">
                    <div className="flex items-end space-x-3">
                      <textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                        placeholder={(t as any)?.messagesArea?.input?.placeholder || 'Type your message...'}
                        rows={1}
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6B35] focus:border-transparent resize-none"
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim()}
                        className="px-6 py-3 bg-[#FF6B35] text-white rounded-lg font-medium hover:bg-[#ff5722] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                        </svg>
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      {(t as any)?.messagesArea?.input?.hint || 'Press Enter to send, Shift + Enter for new line'}
                    </p>
                  </div>
                </>
              ) : messagesLoading ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF6B35] mx-auto"></div>
                    <p className="mt-4 text-gray-600">{(t as any)?.messagesArea?.loading || 'Loading messages...'}</p>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center bg-gray-50">
                  <div className="text-center">
                    <svg
                      className="mx-auto h-16 w-16 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                      />
                    </svg>
                    <h3 className="mt-4 text-lg font-medium text-gray-900">
                      {(t as any)?.messagesArea?.emptyState?.title || 'Select a conversation'}
                    </h3>
                    <p className="mt-2 text-gray-500">
                      {(t as any)?.messagesArea?.emptyState?.subtitle || 'Choose a conversation from the list to start messaging'}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Delete Message Modal */}
      {showDeleteModal && messageToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="mt-4 text-lg font-semibold text-gray-900 text-center">
                {(t as any)?.deleteModal?.title || 'Delete Message'}
              </h3>
              <p className="mt-2 text-sm text-gray-500 text-center">
                {(t as any)?.deleteModal?.message || 'Are you sure you want to delete this message? This action cannot be undone.'}
              </p>
            </div>

            <div className="bg-gray-50 px-6 py-4 flex items-center justify-end gap-4 rounded-b-xl">
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setMessageToDelete(null);
                }}
                className="px-6 py-3 text-gray-700 bg-white border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                {(t as any)?.deleteModal?.cancel || 'Cancel'}
              </button>
              <button
                onClick={handleDeleteMessage}
                className="px-6 py-3 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors"
              >
                {(t as any)?.deleteModal?.confirm || 'Delete Message'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Archive/Unarchive Conversation Modal */}
      {showArchiveModal && conversationToArchive && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6">
              <div
                className={`flex items-center justify-center w-12 h-12 mx-auto rounded-full ${
                  conversationToArchive.status === 'active'
                    ? 'bg-purple-100'
                    : 'bg-green-100'
                }`}
              >
                <svg
                  className={`w-6 h-6 ${
                    conversationToArchive.status === 'active'
                      ? 'text-purple-600'
                      : 'text-green-600'
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                </svg>
              </div>
              <h3 className="mt-4 text-lg font-semibold text-gray-900 text-center">
                {conversationToArchive.status === 'active'
                  ? ((t as any)?.archiveModal?.archiveTitle || 'Archive Conversation')
                  : ((t as any)?.archiveModal?.unarchiveTitle || 'Unarchive Conversation')}
              </h3>
              <p className="mt-2 text-sm text-gray-500 text-center">
                {conversationToArchive.status === 'active'
                  ? ((t as any)?.archiveModal?.archiveMessage || 'This conversation will be moved to archived. You can restore it later.')
                  : ((t as any)?.archiveModal?.unarchiveMessage || 'This conversation will be moved back to active conversations.')}
              </p>
            </div>

            <div className="bg-gray-50 px-6 py-4 flex items-center justify-end gap-4 rounded-b-xl">
              <button
                onClick={() => {
                  setShowArchiveModal(false);
                  setConversationToArchive(null);
                }}
                className="px-6 py-3 text-gray-700 bg-white border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                {(t as any)?.archiveModal?.cancel || 'Cancel'}
              </button>
              <button
                onClick={handleArchiveConversation}
                className={`px-6 py-3 text-white rounded-lg font-medium transition-colors ${
                  conversationToArchive.status === 'active'
                    ? 'bg-purple-600 hover:bg-purple-700'
                    : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {conversationToArchive.status === 'active' ? ((t as any)?.archiveModal?.confirmArchive || 'Archive') : ((t as any)?.archiveModal?.confirmUnarchive || 'Unarchive')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Conversation Modal */}
      {showNewConversationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 text-center">
                {(t as any)?.newConversationModal?.title || 'Start New Conversation'}
              </h3>
              <p className="mt-2 text-sm text-gray-500 text-center">
                {(t as any)?.newConversationModal?.message || 'To start a new conversation, please browse listings and contact the host from the listing page.'}
              </p>
            </div>

            <div className="bg-gray-50 px-6 py-4 flex items-center justify-end gap-4 rounded-b-xl">
              <button
                onClick={() => setShowNewConversationModal(false)}
                className="px-6 py-3 text-gray-700 bg-white border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                {(t as any)?.newConversationModal?.close || 'Close'}
              </button>
              <button
                onClick={() => router.push('/search')}
                className="px-6 py-3 bg-[#FF6B35] text-white rounded-lg font-medium hover:bg-[#ff5722] transition-colors"
              >
                {(t as any)?.newConversationModal?.browseListings || 'Browse Listings'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
