const express = require('express');
const Listing = require('../models/Listing');
const {
  getListings,
  getListing,
  createListing,
  updateListing,
  deleteListing,
  getListingsByHost,
  getMyListings,
  toggleFavorite,
  getFeaturedListings,
  advancedSearch,
  getSearchSuggestions,
  getFilters
} = require('../controllers/listingController');
const { protect, hostOrAdmin, optionalAuth } = require('../middleware/auth');
const {
  createListingValidation,
  updateListingValidation,
  searchValidation,
  mongoIdValidation
} = require('../utils/validation');
const { uploadListingImage, handleUploadError } = require('../middleware/upload');

const router = express.Router();

// Public routes (no authentication required)
router.get('/', searchValidation, optionalAuth, getListings);
router.get('/filters', getFilters);
router.get('/featured', getFeaturedListings);
router.get('/suggestions', getSearchSuggestions);
router.post('/search', advancedSearch);
router.get('/host/:hostId', mongoIdValidation, getListingsByHost);
router.get('/:id', mongoIdValidation, optionalAuth, getListing); // Public listing detail

// Protected routes - Must come AFTER public routes
router.use(protect); // All routes below this middleware are protected

// Image upload route - must come before /:id route
router.post('/upload-images', uploadListingImage.array('images', 10), handleUploadError, (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        status: 'error',
        message: 'No images uploaded'
      });
    }

    const uploadedImages = req.files.map(file => ({
      url: `/uploads/listings/${file.filename}`,
      caption: '',
      isPrimary: false
    }));

    res.status(200).json({
      status: 'success',
      data: {
        images: uploadedImages
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

// My listings - must come before /:id route
router.get('/my/listings', getMyListings);

// Create listing
router.post('/', createListingValidation, hostOrAdmin, createListing);

// Specific listing operations by ID - these are protected routes
router.put('/:id', mongoIdValidation, updateListingValidation, updateListing);
router.delete('/:id', mongoIdValidation, deleteListing);
router.post('/:id/favorite', mongoIdValidation, toggleFavorite);

// Test route
router.get('/test/status', (req, res) => {
  res.json({
    status: 'success',
    message: 'Listings routes working',
    timestamp: new Date().toISOString()
  });
});
// Pause/Activate listing
router.patch('/:id/status', mongoIdValidation, async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);
    
    if (!listing) {
      return res.status(404).json({
        status: 'error',
        message: 'Listing not found'
      });
    }

    // Check if user is the owner or admin
    if (listing.host.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to modify this listing'
      });
    }

    // Toggle between active and paused
    listing.status = listing.status === 'active' ? 'paused' : 'active';
    await listing.save();

    res.status(200).json({
      status: 'success',
      data: {
        listing
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

// Duplicate listing
router.post('/:id/duplicate', mongoIdValidation, async (req, res) => {
  try {
    const originalListing = await Listing.findById(req.params.id);
    
    if (!originalListing) {
      return res.status(404).json({
        status: 'error',
        message: 'Listing not found'
      });
    }

    // Check if user is the owner or admin
    if (originalListing.host.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to duplicate this listing'
      });
    }

    // Create a copy of the listing
    const listingData = originalListing.toObject();
    delete listingData._id;
    delete listingData.createdAt;
    delete listingData.updatedAt;
    delete listingData.__v;
    
    // Modify title to indicate it's a copy
    listingData.title = `${listingData.title} (Copy)`;
    listingData.status = 'draft'; // New copy starts as draft
    listingData.host = req.user.id;

    const newListing = await Listing.create(listingData);

    res.status(201).json({
      status: 'success',
      data: {
        listing: newListing
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

 module.exports = router;
