'use client';

import React, { useState, useEffect, useCallback, Suspense, useMemo, useRef } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useSocketListings, useSocketConnection } from '@/hooks/useSocket';
import FilterSidebar from '@/components/search/FilterSidebar';
import SearchResults from '@/components/search/SearchResults';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Listing } from '@/types';
import { MapPin, Grid3X3 } from 'lucide-react';

// Enhanced lazy loading with better error boundaries
import dynamic from 'next/dynamic';

const EnhancedMapView = dynamic(
  () => import('@/components/search/EnhancedMapView'),
  {
    loading: () => (
      <div className="w-full h-full bg-gray-100 rounded-2xl flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF6B35] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading enhanced map...</p>
        </div>
      </div>
    ),
    ssr: false
  }
);

const MapModal = dynamic(
  () => import('@/components/search/MapModal'),
  {
    loading: () => <div>Loading map modal...</div>,
    ssr: false
  }
);

interface SearchFilters {
  location: string;
  category: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  adults: number;
  children: number;
  priceRange: [number, number];
  propertyTypes: string[];
  bedrooms: string;
  bathrooms: string;
  amenities: string[];
  instantBook: boolean;
  superhost: boolean;
  sort: string;
  // Vehicle-specific
  driverAge: string;
  pickupTime: string;
  returnTime: string;
}

function SearchPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { language, currency } = useLanguage();
  const t = useTranslation('search') as any;

  // Socket.IO hooks
  const { isConnected, connectionError } = useSocketConnection();
  const {
    listings: socketListings,
    loading: socketLoading,
    error: socketError,
    hasMore: socketHasMore,
    totalResults: socketTotalResults,
    searchListings,
    loadMore
  } = useSocketListings();

  // Enhanced state management
  const [filteredListings, setFilteredListings] = useState<Listing[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'map'>(
    searchParams?.get('view') === 'map' ? 'map' : 'list'
  );
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [selectedListing, setSelectedListing] = useState<string | null>(null);
  const [hoveredListing, setHoveredListing] = useState<string | null>(null);

  // Map bounds filtering - SAME AS HOMEPAGE
  const [mapBounds, setMapBounds] = useState<google.maps.LatLngBounds | null>(null);
  const [isMapFiltering, setIsMapFiltering] = useState(false);

  // Enhanced state for REST API fallback
  const [restApiListings, setRestApiListings] = useState<Listing[]>([]);
  const [restApiLoading, setRestApiLoading] = useState(false);
  const [restApiError, setRestApiError] = useState<string | null>(null);

  // Derive state from socket data or REST API fallback
  const useRestAPI = !isConnected;
  const listings = useRestAPI ? restApiListings : socketListings;
  const loading = useRestAPI ? restApiLoading : socketLoading;
  const error = useRestAPI ? restApiError : (socketError || (connectionError ? `${t.connection?.error || 'Connection error'}: ${connectionError}` : null));
  const totalResults = useRestAPI ? restApiListings.length : socketTotalResults;
  const hasMore = useRestAPI ? false : socketHasMore;

  // Initialize filters from URL params with enhanced support
  const [filters, setFilters] = useState<SearchFilters>({
    location: searchParams?.get('location') || '',
    category: searchParams?.get('category') || 'stays',
    checkIn: searchParams?.get('checkIn') || '',
    checkOut: searchParams?.get('checkOut') || '',
    guests: parseInt(searchParams?.get('guests') || '0'),
    adults: parseInt(searchParams?.get('adults') || '1'),
    children: parseInt(searchParams?.get('children') || '0'),
    priceRange: [0, 100000],
    propertyTypes: [],
    bedrooms: searchParams?.get('bedrooms') || 'any',
    bathrooms: searchParams?.get('bathrooms') || 'any',
    amenities: [],
    instantBook: false,
    superhost: false,
    sort: 'recommended',
    // Vehicle-specific
    driverAge: searchParams?.get('driverAge') || '25+',
    pickupTime: searchParams?.get('pickupTime') || '',
    returnTime: searchParams?.get('returnTime') || '',
  });

  // Enhanced search functionality with better error handling
  const performSearch = useCallback(async (pageNum = 1, append = false) => {
    const apiFilters = {
      ...filters,
      category: filters.category === 'stays' ? 'stay' :
               filters.category === 'vehicles' ? 'vehicle' :
               filters.category === 'stay' || filters.category === 'vehicle' ? filters.category :
               'stay',
      // Map checkIn/checkOut to startDate/endDate for API
      startDate: filters.checkIn,
      endDate: filters.checkOut,
      // Remove checkIn/checkOut to avoid confusion
      checkIn: undefined,
      checkOut: undefined,
      page: pageNum,
      limit: 20
    };

    try {
      if (!useRestAPI) {
        await searchListings(apiFilters, append);
      } else {
        setRestApiLoading(true);
        setRestApiError(null);

        const { listingsAPI } = await import('@/lib/api');
        const response = await listingsAPI.searchListings(apiFilters);

        if (response.success) {
          const newListings = response.data.data.listings || [];

          // Enhanced listing transformation with CONSISTENT coordinate handling (SAME AS HOMEPAGE)
          const transformedListings = newListings.map((listing: any) => {
            // IMPORTANT: Convert GeoJSON [lng, lat] to Google Maps [lat, lng] format
            const coords = listing.location?.coordinates ?
              [listing.location.coordinates[1], listing.location.coordinates[0]] : // Swap [lng, lat] to [lat, lng]
              [36.7538, 3.0588]; // Default to Algiers [lat, lng]

            return {
            id: listing._id || listing.id,
            _id: listing._id || listing.id,
            title: listing.title,
            category: listing.category,
            subcategory: listing.subcategory,
            // IMPORTANT: Set up address structure SAME AS HOMEPAGE
            address: {
              street: listing.address?.street || '',
              city: listing.address?.city || '',
              state: listing.address?.state || '',
              country: listing.address?.country || '',
              zipCode: listing.address?.zipCode || '',
              // Store coordinates in Google Maps [lat, lng] format for consistency
              coordinates: coords
            },
            location: {
              // Keep original for backward compatibility
              coordinates: listing.location?.coordinates || [3.0588, 36.7538]
            },
            // Add displayCoordinates for EnhancedMapView compatibility
            displayCoordinates: coords,
            pricing: {
              basePrice: listing.pricing?.basePrice || 0,
              currency: listing.pricing?.currency || 'DZD',
              convertedPrice: listing.pricing?.convertedPrice,
              cleaningFee: listing.pricing?.cleaningFee || 0,
              serviceFee: listing.pricing?.serviceFee || 0,
              securityDeposit: listing.pricing?.securityDeposit || 0
            },
            stats: {
              averageRating: listing.stats?.averageRating || 0,
              reviewCount: listing.stats?.reviewCount || 0,
              views: listing.stats?.views || 0,
              favorites: listing.stats?.favorites || 0
            },
            images: (listing.images || []).map((img: any) =>
              typeof img === 'string' ? img : (img?.url || img)
            ).filter(Boolean),
            host: listing.host ? {
              _id: listing.host._id || listing.host.id,
              firstName: listing.host.firstName,
              lastName: listing.host.lastName,
              avatar: listing.host.avatar,
              stats: {
                averageRating: listing.host.stats?.averageRating || 0
              },
              hostInfo: {
                superhost: listing.host.hostInfo?.superhost || false
              }
            } : null,
            availability: listing.availability,
            status: listing.status,
            featured: listing.featured,
            // Enhanced category-specific details
            ...(listing.category === 'stay' && {
              propertyDetails: {
                propertyType: listing.stayDetails?.stayType,
                bedrooms: listing.stayDetails?.bedrooms,
                bathrooms: listing.stayDetails?.bathrooms,
                area: listing.stayDetails?.area,
                furnished: listing.stayDetails?.furnished,
                amenities: listing.stayDetails?.amenities || []
              },
              stayDetails: {
                stayType: listing.stayDetails?.stayType,
                bedrooms: listing.stayDetails?.bedrooms,
                bathrooms: listing.stayDetails?.bathrooms,
                area: listing.stayDetails?.area,
                furnished: listing.stayDetails?.furnished,
                amenities: listing.stayDetails?.amenities || []
              }
            }),
            ...(listing.category === 'vehicle' && {
              vehicleDetails: {
                vehicleType: listing.vehicleDetails?.vehicleType,
                make: listing.vehicleDetails?.make,
                model: listing.vehicleDetails?.model,
                year: listing.vehicleDetails?.year,
                transmission: listing.vehicleDetails?.transmission,
                fuelType: listing.vehicleDetails?.fuelType,
                seats: listing.vehicleDetails?.seats,
                features: listing.vehicleDetails?.features || []
              }
            })
          };
          });

          if (append) {
            setRestApiListings(prev => [...prev, ...transformedListings]);
          } else {
            setRestApiListings(transformedListings);
          }
        }
      }
    } catch (error: any) {
      if (useRestAPI) {
        setRestApiError(error.message || t.connection?.failed || 'Failed to search listings');
      }
    } finally {
      if (useRestAPI) {
        setRestApiLoading(false);
      }
    }
  }, [filters, searchListings, isConnected, useRestAPI]);

  // Update filters when URL params change
  useEffect(() => {
    if (searchParams) {
      setFilters(prev => ({
        ...prev,
        location: searchParams.get('location') || prev.location,
        category: searchParams.get('category') || prev.category,
        checkIn: searchParams.get('checkIn') || prev.checkIn,
        checkOut: searchParams.get('checkOut') || prev.checkOut,
        guests: parseInt(searchParams.get('guests') || '0') || prev.guests,
        adults: parseInt(searchParams.get('adults') || '1') || prev.adults,
        children: parseInt(searchParams.get('children') || '0') || prev.children,
      }));
    }
  }, [searchParams]);

  // Search listings when filters change
  useEffect(() => {
    performSearch(1, false);
  }, [performSearch]);

  // Helper function to check if listing is within map bounds - SAME AS HOMEPAGE
  const isListingInBounds = useCallback((listing: Listing, bounds: google.maps.LatLngBounds): boolean => {
    // IMPORTANT: Use address.coordinates which is in [lat, lng] format (same as homepage)
    const coords = (listing as any).address?.coordinates || (listing as any).displayCoordinates;

    if (!coords || !Array.isArray(coords) || coords.length !== 2) {
      return false;
    }

    // Coordinates are already in [lat, lng] format after transformation
    const [lat, lng] = coords;

    if (isNaN(lat) || isNaN(lng)) {
      return false;
    }

    const isInBounds = bounds.contains({ lat, lng });
    return isInBounds;
  }, []);

  // Update display listings when map bounds change or listings change - SAME AS HOMEPAGE
  useEffect(() => {
    if (mapBounds && listings.length > 0) {
      // Filter listings by map bounds when bounds exist
      const boundsFiltered = listings.filter(listing =>
        isListingInBounds(listing, mapBounds)
      );
      setFilteredListings(boundsFiltered);
      setIsMapFiltering(true);
    } else {
      // Show all listings when no bounds
      setFilteredListings(listings);
      setIsMapFiltering(false);
    }
  }, [mapBounds, listings, isListingInBounds]);

  // Enhanced client-side filtering and sorting
  useEffect(() => {
    // Skip if map is handling the filtering
    if (mapBounds && isMapFiltering) {
      return;
    }

    let filtered = [...listings];

    // Apply instant filters
    if (filters.instantBook) {
      filtered = filtered.filter(l => l.availability?.instantBook);
    }
    if (filters.superhost) {
      filtered = filtered.filter(l => l.host?.hostInfo?.superhost);
    }

    // Apply sorting
    switch (filters.sort) {
      case 'price_low':
        filtered.sort((a, b) => (a.pricing?.basePrice || 0) - (b.pricing?.basePrice || 0));
        break;
      case 'price_high':
        filtered.sort((a, b) => (b.pricing?.basePrice || 0) - (a.pricing?.basePrice || 0));
        break;
      case 'rating':
        filtered.sort((a, b) => (b.stats?.averageRating || 0) - (a.stats?.averageRating || 0));
        break;
      case 'reviews':
        filtered.sort((a, b) => (b.stats?.reviewCount || 0) - (a.stats?.reviewCount || 0));
        break;
      case 'featured':
        filtered.sort((a, b) => {
          if (a.featured && !b.featured) return -1;
          if (!a.featured && b.featured) return 1;
          return (b.stats?.averageRating || 0) - (a.stats?.averageRating || 0);
        });
        break;
    }

    if (!mapBounds) {
      setFilteredListings(filtered);
    }
  }, [listings, mapBounds, isMapFiltering, filters.instantBook, filters.superhost, filters.sort]);

  // Handle load more
  const handleLoadMore = () => {
    if (!loading && hasMore) {
      loadMore();
    }
  };

  // Enhanced URL management
  const updateURL = useCallback((newFilters: SearchFilters) => {
    const params = new URLSearchParams();
    Object.entries(newFilters).forEach(([key, value]) => {
      if (value && value !== 'any' && value !== 0 && (Array.isArray(value) ? value.length > 0 : true)) {
        if (Array.isArray(value)) {
          params.append(key, value.join(','));
        } else {
          params.append(key, String(value));
        }
      }
    });
    router.push(`/search?${params.toString()}`, { scroll: false });
  }, [router]);

  // Handle filter changes
  const handleFilterChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
    updateURL(newFilters);
  };

  // Enhanced view mode handling with map modal
  const handleViewModeChange = (mode: 'list' | 'map') => {
    setViewMode(mode);
    if (mode === 'map') {
      setIsMapModalOpen(true);
    }
    const params = new URLSearchParams(window.location.search);
    if (mode === 'map') {
      params.set('view', 'map');
    } else {
      params.delete('view');
    }
    router.push(`/search?${params.toString()}`, { scroll: false });
  };

  // Handle listing interactions
  const handleListingSelect = (id: string) => {
    setSelectedListing(selectedListing === id ? null : id);
  };

  const handleListingHover = (id: string | null) => {
    setHoveredListing(id);
  };

  // Handle map bounds change - SAME AS HOMEPAGE with persistence
  const handleMapBoundsChange = useCallback((bounds: google.maps.LatLngBounds | null) => {
    setMapBounds(bounds);
  }, []);

  // Enhanced Loading Skeleton
  const LoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
      {[...Array(8)].map((_, i) => (
        <div key={i} className="bg-white rounded-2xl shadow-sm overflow-hidden animate-pulse">
          <div className="aspect-[4/3] bg-gray-200" />
          <div className="p-4 space-y-3">
            <div className="h-4 bg-gray-200 rounded" />
            <div className="h-3 bg-gray-200 rounded w-2/3" />
            <div className="h-4 bg-gray-200 rounded w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );

  const seoTitle = useMemo(() => {
    const categoryText = filters.category === 'stays' ? (t.categories?.properties || 'Properties') : (t.categories?.vehicles || 'Vehicles');
    const location = filters.location || (t.seo?.algeria || 'Algeria');
    return `${t.seo?.find || 'Find'} ${categoryText} ${t.seo?.in || 'in'} ${location} - ${t.seo?.baytup || 'Baytup'}`;
  }, [filters, t]);

  const seoDescription = useMemo(() => {
    const categoryText = filters.category === 'stays' ? (t.categories?.accommodations || 'accommodations') : (t.categories?.vehicles?.toLowerCase() || 'vehicles');
    return `${t.seo?.discover || 'Discover and book amazing'} ${categoryText} ${t.seo?.in || 'in'} ${t.seo?.algeria || 'Algeria'}. ${t.seo?.browse || 'Browse'} ${totalResults}+ ${t.seo?.verified || 'verified listings with instant booking, reviews, and competitive prices.'}`;
  }, [filters, totalResults, t]);

  // Enhanced breadcrumb navigation
  const breadcrumbs = [
    { name: t.breadcrumbs?.home || 'Home', href: '/' },
    { name: t.breadcrumbs?.search || 'Search', href: '/search' },
    ...(filters.location ? [{ name: filters.location, href: `/search?location=${filters.location}` }] : [])
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      {/* SEO Head Tags */}
      <head>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />
        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
      </head>

      {/* Enhanced Header with Stats */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              {/* Breadcrumbs */}
              <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                {breadcrumbs.map((crumb, index) => (
                  <React.Fragment key={index}>
                    {index > 0 && <span className="text-gray-400">/</span>}
                    {index === breadcrumbs.length - 1 ? (
                      <span className="text-gray-900 font-semibold">{crumb.name}</span>
                    ) : (
                      <a href={crumb.href} className="hover:text-[#FF6B35] transition-colors">
                        {crumb.name}
                      </a>
                    )}
                  </React.Fragment>
                ))}
              </nav>

              {/* Title and Results Count */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900 flex items-center gap-3">
                    {filters.location ? (
                      <>
                        {filters.location}
                        <span className="text-gray-400 font-normal text-xl">
                          {filters.category === 'stays' ? t.categories?.stays : t.categories?.vehicles}
                        </span>
                      </>
                    ) : (
                      <>{filters.category === 'stays' ? t.categories?.stays : t.categories?.vehicles} {t.results?.inAlgeria || 'in Algeria'}</>
                    )}
                  </h1>
                  <p className="text-gray-600 mt-1 flex items-center gap-4">
                    <span className="font-semibold text-[#FF6B35]">
                      {loading ? (
                        <span className="inline-block w-10 h-4 bg-gray-200 rounded animate-pulse" />
                      ) : (
                        filteredListings.length
                      )}
                    </span>{' '}
                    {t.results?.resultText || 'results found'}
                    {isMapFiltering && mapBounds && (
                      <span className="text-sm text-blue-600 font-medium flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {t.map?.withinMap || 'Within map area'}
                      </span>
                    )}
                    {filters.checkIn && filters.checkOut && (
                      <span className="text-sm text-gray-500">
                        {filters.checkIn} - {filters.checkOut}
                      </span>
                    )}
                  </p>
                </div>

                {/* View Mode Toggle */}
                <div className="hidden md:flex items-center gap-2 bg-gray-100 p-1 rounded-xl">
                  <button
                    onClick={() => handleViewModeChange('list')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center gap-2 ${
                      viewMode === 'list'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <Grid3X3 className="w-4 h-4" />
                    {t.view?.list || 'List'}
                  </button>
                  <button
                    onClick={() => handleViewModeChange('map')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center gap-2 ${
                      viewMode === 'map'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <MapPin className="w-4 h-4" />
                    {t.view?.map || 'Map'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-8">
          {/* Enhanced Sidebar - Desktop */}
          <aside className="hidden lg:block w-80 flex-shrink-0">
            <div className="sticky top-24">
              <FilterSidebar
                filters={filters}
                onFilterChange={handleFilterChange}
                category={filters.category}
              />
            </div>
          </aside>

          {/* Main Results Area */}
          <div className="flex-1">
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700">
                {error}
              </div>
            )}

            {loading && filteredListings.length === 0 ? (
              <LoadingSkeleton />
            ) : filteredListings.length === 0 ? (
              /* Enhanced Empty State */
              <div className="bg-white rounded-3xl shadow-sm p-12 text-center">
                <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center">
                  <MapPin className="w-16 h-16 text-gray-400" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  {t.empty?.title || 'No results found'}
                </h2>
                <p className="text-gray-600 mb-8 max-w-md mx-auto">
                  {t.empty?.description || 'Try adjusting your filters or search in a different area'}
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => handleFilterChange({ ...filters, location: '' })}
                    className="px-6 py-3 bg-[#FF6B35] hover:bg-orange-600 text-white rounded-xl font-medium transition-colors duration-200"
                  >
                    {t.empty?.clearLocation || 'Clear Location'}
                  </button>
                  <button
                    onClick={() => window.location.href = '/'}
                    className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-colors duration-200"
                  >
                    {t.empty?.backToHome || 'Back to Home'}
                  </button>
                </div>
              </div>
            ) : (
              <div>
                {/* Connection Status */}
                {!isConnected && (
                  <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-yellow-800 text-sm">
                    {t.connection?.offline || 'Using offline mode. Real-time updates disabled.'}
                  </div>
                )}

                {/* Enhanced Search Results */}
                {isMapFiltering && mapBounds && (
                  <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-xl">
                    <p className="text-sm text-blue-800 font-medium flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {t.map?.mapFilterMessage || 'Showing only listings visible on the map. Close map to see all results.'}
                    </p>
                  </div>
                )}
                <SearchResults
                  listings={filteredListings}
                  loading={loading}
                  hasMore={hasMore && !isMapFiltering} // Disable load more when map is filtering
                  onLoadMore={handleLoadMore}
                  currency={currency}
                  language={language}
                />

                {/* Floating Map Button - Always visible like home page */}
                <div className="fixed bottom-8 right-8 z-30">
                  <button
                    onClick={() => setIsMapModalOpen(true)}
                    className="group flex items-center gap-3 bg-gradient-to-r from-[#FF6B35] to-[#F7931E] hover:from-[#E55A2B] hover:to-[#E57F1B] text-white pl-6 pr-7 py-4 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105"
                  >
                    <MapPin className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                    <span className="font-bold text-base">
                      {t.map?.showCategoryOnMap?.replace('{category}', filters.category === 'stays' ? t.categories?.stays : t.categories?.vehicles) || 'Show on Map'}
                    </span>
                    {filteredListings.length > 0 && (
                      <span className="bg-white/20 text-white text-sm font-semibold px-2.5 py-1 rounded-full">
                        {filteredListings.length}
                      </span>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Enhanced Map Modal - SAME AS HOMEPAGE with persistent filtering */}
      <MapModal
        isOpen={isMapModalOpen}
        onClose={() => {
          setIsMapModalOpen(false);
          setViewMode('list');
          // DON'T clear mapBounds - keep them to persist the filter (same as homepage)
        }}
        listings={listings} // Show all listings in map for exploration
        selectedListing={selectedListing}
        onListingSelect={handleListingSelect}
        onListingHover={handleListingHover}
        onMapBoundsChange={handleMapBoundsChange}
        filters={filters}
        onFilterChange={handleFilterChange}
        title={t.map?.title?.replace('Properties', filters.category === 'stays' ? (t.categories?.stays || 'Stays') : (t.categories?.vehicles || 'Vehicles')) || 'Explore on Map'}
      />
    </div>
  );
}

// Enhanced Loading skeleton for the entire page
const SearchPageSkeleton = () => (
  <div className="min-h-screen bg-gray-50">
    <div className="bg-white border-b">
      <div className="container mx-auto px-4 py-6">
        <div className="h-8 bg-gray-200 rounded w-1/3 animate-pulse mb-2" />
        <div className="h-4 bg-gray-200 rounded w-1/4 animate-pulse" />
      </div>
    </div>
    <div className="container mx-auto px-4 py-8">
      <div className="flex gap-8">
        <div className="hidden lg:block w-80">
          <div className="bg-white rounded-2xl h-96 animate-pulse" />
        </div>
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="aspect-[4/3] bg-gray-200 animate-pulse" />
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-200 rounded animate-pulse" />
                  <div className="h-3 bg-gray-200 rounded w-2/3 animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-1/2 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Main component with enhanced Suspense boundary
export default function SearchPage() {
  return (
    <Suspense fallback={<SearchPageSkeleton />}>
      <SearchPageContent />
    </Suspense>
  );
}